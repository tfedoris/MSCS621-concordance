# coding: utf-8

# flake8: noqa
from __future__ import absolute_import
# import models into model package
from swagger_server.models.location_result import LocationResult
from swagger_server.models.location_result_concordance import LocationResultConcordance
from swagger_server.models.result import Result
from swagger_server.models.result_concordance import ResultConcordance
